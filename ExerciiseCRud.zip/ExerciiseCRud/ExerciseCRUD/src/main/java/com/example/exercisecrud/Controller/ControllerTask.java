package com.example.exercisecrud.Controller;
import com.example.exercisecrud.Api.ApiResponse;
import com.example.exercisecrud.Model.Tasskk;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/v1/taskk")
public class ControllerTask {
    ArrayList<Tasskk> tasks = new ArrayList<>();


    @GetMapping("/get")
    public ArrayList<Tasskk> getTask(){
        return tasks;
    }

    @PostMapping("/add")
    public ApiResponse addTask(@RequestBody Tasskk task){
        tasks.add(task);
        return new ApiResponse("added");
    }
    @PutMapping("/update/{index}")
    public ApiResponse updateTask(@PathVariable int index, @RequestBody Tasskk task){
        tasks.set(index, task);
        return new ApiResponse("Updated Successfully");
    }

    @DeleteMapping("/delete/{index}")
    public ApiResponse deleteTask(@PathVariable int index){
        tasks.remove(index);
        return new ApiResponse("deleted Successfully");
    }

    @DeleteMapping("delete/all")
    public ApiResponse deleteAllTasks(){
        tasks.clear();
        return new ApiResponse("All Tasks Deleted");
    }


    @PutMapping("/change-status/{id}")
    public ApiResponse changeTaskStatus(@PathVariable String id){
        for (Tasskk task : tasks){
            if (task.getID().equals(id)){
                task.setStatus((!task.isStatus()));
                return new ApiResponse("Taks Status changed successfully!");
            }
        }
        return new ApiResponse("Task not found!");
    }

    @GetMapping("/search/{title}")
    public ArrayList<Tasskk> searchTaskByTitle(@PathVariable String title){
        ArrayList<Tasskk> result = new ArrayList<>();
        for (Tasskk task : tasks){
            if (task.getTitle().equalsIgnoreCase(title)){
                result.add(task);
            }
        }
        return result;
    }
}