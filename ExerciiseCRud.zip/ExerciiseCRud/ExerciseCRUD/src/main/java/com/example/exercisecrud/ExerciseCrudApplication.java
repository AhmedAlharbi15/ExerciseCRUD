package com.example.exercisecrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciseCrudApplication {

    public static void main(String[] args)
    {
        SpringApplication.run(ExerciseCrudApplication.class, args);
    }

}
