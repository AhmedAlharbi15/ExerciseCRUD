package com.example.exercisecrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerciseCrudApplicationTests {

    @Test
    void contextLoads() {
    }

}
