package com.example.exercisecrud2.Controller;

import com.example.exercisecrud2.Model.Customers;
import org.springframework.web.bind.annotation.*;
import com.example.exercisecrud2.Api.ApiResponse;
import java.util.ArrayList;

@RestController
@RequestMapping("api/v1/bank")
public class BankCustomers {
    ArrayList<Customers> customers = new ArrayList<>();
    @GetMapping("/get")
    public ArrayList<Customers> getCustomers(){
        return customers;
    }

    @PostMapping("add")
    public ApiResponse addCustomer(@RequestBody Customers customer){
        customers.add(customer);
        return new ApiResponse("Added");
    }


    @PutMapping("/update/{index}")
    public ApiResponse updateCustomer(@PathVariable int index, @RequestBody Customers customer){
        customers.set(index, customer);
        return new ApiResponse("updated successfully");
    }

    @DeleteMapping("/delete/{index}")
    public ApiResponse delete(@PathVariable int index){
        customers.remove(index);
        return new ApiResponse("Deleted Successfully");
    }

    @DeleteMapping("/delete/all")
    public ApiResponse deleteAll(){
        customers.clear();
        return new ApiResponse("All Customers Deleted Successfully");
    }

    @PostMapping("/deposit/{index}/{amount}")
    public ApiResponse depositMoney(@PathVariable int index, @PathVariable float amount){
        Customers customer = customers.get(index);
        customer.balance += amount;
        return new ApiResponse("Money Deposited Successfully");
    }

    @PostMapping("/withdraw/{index}/{amount}")
    public ApiResponse withdrawMoney(@PathVariable int index, @PathVariable float amount) {
        Customers customer = customers.get(index);
        if (customer.balance >= amount) {
            customer.balance -= amount;
            return new ApiResponse("Money Withdrawn Successfully");
        } else {
            return new ApiResponse("Insufficient Balance");
        }

    }
}