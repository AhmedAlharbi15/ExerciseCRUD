package com.example.exercisecrud2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciseCrud2Application {

	public static void main(String[] args) {
		SpringApplication.run(ExerciseCrud2Application.class, args);
	}

}
